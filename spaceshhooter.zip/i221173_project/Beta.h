/*
 * Beta.h
 *
 *  Created on: May 13, 2023
 *      Author: moaz
 */

#ifndef BETA_H_
#define BETA_H_
#include "Invader.h"
class Beta:public Invader {
public:
	Beta();
	virtual ~Beta();
};

#endif /* BETA_H_ */
