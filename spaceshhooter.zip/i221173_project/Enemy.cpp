/*
 * Enemy.cpp
 *
 *  Created on: May 12, 2023
 *      Author: moaz
 */

#include "Enemy.h"

Enemy::Enemy()
{
	type = '0';
	lives = 0;
}

Enemy::~Enemy() {
	// TODO Auto-generated destructor stub
}

