/*
 * Add_on.cpp
 *
 *  Created on: May 11, 2023
 *      Author: moaz
 */
#include "Add_on.h"

Add_on::Add_on()
{
	hit_x=0;
	hit_y=0;
	type='0';
}
Add_on::~Add_on()
{

}


