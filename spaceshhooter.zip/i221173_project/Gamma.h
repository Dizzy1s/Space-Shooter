/*
 * Gamma.h
 *
 *  Created on: May 14, 2023
 *      Author: moaz
 */

#ifndef GAMMA_H_
#define GAMMA_H_
#include "Invader.h"
class Gamma : public Invader {
public:
	Gamma();
	virtual ~Gamma();
};

#endif /* GAMMA_H_ */
