/*
 * Alpha.h
 *
 *  Created on: May 13, 2023
 *      Author: moaz
 */

#ifndef ALPHA_H_
#define ALPHA_H_
#include "Invader.h"
class Alpha : public Invader{
public:
	Alpha();
	virtual ~Alpha();
};

#endif /* ALPHA_H_ */
